#include "../Drivers/IO/TextPrint.cpp"
#include "../Drivers/IDT/IDT.cpp"

extern const char SuccessAscii[];

extern "C" void _start() {
    SetCursorPosition(PositionFromCoords(0, 0));
    ClearScreen();
    PrintString(SuccessAscii);

    InitializeIDT();
    return;
}